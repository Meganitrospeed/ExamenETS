public class circulo {
    double radio;

    public static double area(double radio) {
        double area = Math.PI * Math.pow(radio, 2);
        return area;
    }
}
