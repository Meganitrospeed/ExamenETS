public class Superficie {
    public static void main(String[] args) {

        //RECTANGULO
        System.out.println("Test");
        double base = 2;
        double altura = 2;
        System.out.println(rectangulo.Area(base,altura));
        //FIN RECTANGULO

        //CIRCULO
        double radio = 2;
        System.out.println(circulo.area(radio));
        //FIN CIRCULO

        //CILINDRO
        System.out.println(cilindro.area(10.5,7.3));
        //FIN CILINDRO
    }
}
