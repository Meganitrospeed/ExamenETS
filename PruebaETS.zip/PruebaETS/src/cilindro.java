public class cilindro {
    double radio;
    double altura;
    public static double area(double radio,double altura){
       double area = 2*Math.PI*radio*(radio+altura);
       return area;

    }
}
