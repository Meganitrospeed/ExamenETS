public class rectangulo {
    double base;
    double altura;
    public static double Area (double base, double altura ){
        double area = base*altura;
       return area;
    }

}
